import Paginate from './components/Paginate'

module.exports = Paginate
